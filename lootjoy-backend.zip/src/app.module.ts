import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { MikroOrmModule } from '@mikro-orm/nestjs';
import mikroConfig from '../../lootjoy-backend/common/configs/db/mikro-orm.config';
import { RedisModule } from '../common/adapters/redis/redis.module';
import {HealthModule} from "../common/health/health.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    MikroOrmModule.forRootAsync({ useFactory: () => mikroConfig }),
    HealthModule,
    RedisModule,
  ],
})
export class AppModule {}
